window.JoomlaCalLocale = {
	today : "I dag",
	weekend : [0, 6],
	wk : "uge",
	time : "Tid:",
	days : ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"],
	shortDays : ["Søn", "Man", "Tir", "Ons", "Tor", "Fre", "Lør"],
	months : ["Januar", "Februar", "Marts", "April", "Maj", "Juni", "Juli", "August", "September", "Oktober", "November", "December"],
	shortMonths : ["Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"],
	AM : "AM",
	PM :  "PM",
	am : "am",
	pm : "pm",
	dateType : "gregorian",
	minYear : 1900,
	maxYear : 2100,
	exit: "Luk",
	clear: "Nulstil"
};